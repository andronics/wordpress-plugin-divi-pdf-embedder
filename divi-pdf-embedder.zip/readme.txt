=== Divi PDF Embedder ===
Contributors: andronics
Tags: divi, pdf, embedder
Donate link: https://andronics.me/donate/
License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extends Divi Builder by adding support for the PDF Embedder plugin.

== Changelog ==
v0.1 - 2018-12-05
- Initial version

V0.2 - 2018-12-05
- Added support for sizing width and height
- Added support for toolbar location and state